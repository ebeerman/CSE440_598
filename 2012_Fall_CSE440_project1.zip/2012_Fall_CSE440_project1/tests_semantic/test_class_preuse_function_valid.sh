#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_class_preuse_function_valid.p
