#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_array_multi_bounds_invalid.p
