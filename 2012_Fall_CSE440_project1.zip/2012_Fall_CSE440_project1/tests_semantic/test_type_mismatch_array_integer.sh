#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_type_mismatch_array_integer.p
