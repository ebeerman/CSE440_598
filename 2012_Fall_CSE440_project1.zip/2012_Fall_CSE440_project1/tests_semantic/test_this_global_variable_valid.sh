#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_this_global_variable_valid.p
