#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_if_then_else.p
