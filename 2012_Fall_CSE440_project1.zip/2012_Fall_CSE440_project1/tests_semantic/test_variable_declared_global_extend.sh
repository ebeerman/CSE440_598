#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_variable_declared_global_extend.p
