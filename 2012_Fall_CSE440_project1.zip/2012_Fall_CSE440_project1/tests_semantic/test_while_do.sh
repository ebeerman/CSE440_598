#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_while_do.p
