#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_function_call_class_byref.p
