#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_array_index_boolean.p
