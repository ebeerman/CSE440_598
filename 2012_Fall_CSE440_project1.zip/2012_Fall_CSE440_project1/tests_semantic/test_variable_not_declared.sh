#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_variable_not_declared.p
