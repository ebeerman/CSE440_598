#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_variable_declared_base_class.p
