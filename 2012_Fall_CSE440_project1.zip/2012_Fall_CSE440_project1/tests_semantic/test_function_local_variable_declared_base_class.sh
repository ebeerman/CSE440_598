#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_function_local_variable_declared_base_class.p
