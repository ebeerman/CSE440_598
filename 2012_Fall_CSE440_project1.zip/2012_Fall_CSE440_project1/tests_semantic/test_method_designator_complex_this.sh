#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_method_designator_complex_this.p
