#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_invalid_class_definition_undeclared_vars.p
