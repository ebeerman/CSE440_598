#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_valid_class_definition.p
