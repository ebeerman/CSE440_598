#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_expression_complex.p
