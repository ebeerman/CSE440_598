#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_attribute_designator_multi_this.p
