#!/bin/sh

. ../tests_lib.inc

test_diff_sem test_class_assignment_base_type_valid.p
